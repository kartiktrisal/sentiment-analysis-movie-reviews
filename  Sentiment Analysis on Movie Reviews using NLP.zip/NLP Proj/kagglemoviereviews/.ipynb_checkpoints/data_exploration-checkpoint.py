{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "id": "4f6a1875-8260-40ef-a742-524bdad417dc",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Dataset Overview:\n",
      "   PhraseId  SentenceId                                             Phrase  \\\n",
      "0         1           1  A series of escapades demonstrating the adage ...   \n",
      "1         2           1  A series of escapades demonstrating the adage ...   \n",
      "2         3           1                                           A series   \n",
      "3         4           1                                                  A   \n",
      "4         5           1                                             series   \n",
      "\n",
      "   Sentiment  \n",
      "0          1  \n",
      "1          2  \n",
      "2          2  \n",
      "3          2  \n",
      "4          2  \n",
      "\n",
      "Class Distribution:\n",
      "Sentiment\n",
      "2    79582\n",
      "3    32927\n",
      "1    27273\n",
      "4     9206\n",
      "0     7072\n",
      "Name: count, dtype: int64\n",
      "\n",
      "Sentiment 0 Example:\n",
      "Phrase: would have a hard time sitting through this one\n",
      "\n",
      "Sentiment 1 Example:\n",
      "Phrase: A series of escapades demonstrating the adage that what is good for the goose is also good for the gander , some of which occasionally amuses but none of which amounts to much of a story .\n",
      "\n",
      "Sentiment 2 Example:\n",
      "Phrase: A series of escapades demonstrating the adage that what is good for the goose\n",
      "\n",
      "Sentiment 3 Example:\n",
      "Phrase: good for the goose\n",
      "\n",
      "Sentiment 4 Example:\n",
      "Phrase: This quiet , introspective and entertaining independent is worth seeking .\n"
     ]
    }
   ],
   "source": [
    "import pandas as pd\n",
    "\n",
    "# Load the training data\n",
    "train_data = pd.read_csv('corpus/train.tsv', sep='\\t')\n",
    "\n",
    "# Display the first few rows of the dataset\n",
    "print(\"Dataset Overview:\")\n",
    "print(train_data.head())\n",
    "\n",
    "# Check the class distribution\n",
    "class_distribution = train_data['Sentiment'].value_counts()\n",
    "print(\"\\nClass Distribution:\")\n",
    "print(class_distribution)\n",
    "\n",
    "# Analyze example phrases for each sentiment class\n",
    "for sentiment in sorted(train_data['Sentiment'].unique()):\n",
    "    example = train_data[train_data['Sentiment'] == sentiment].iloc[0]\n",
    "    print(f\"\\nSentiment {sentiment} Example:\")\n",
    "    print(f\"Phrase: {example['Phrase']}\")"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.11.5"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
